/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   CrdCard.h
 * Author: Jeff
 *
 * Created on March 14, 2017, 9:09 PM
 */

#ifndef CRDCARD_H
#define CRDCARD_H

struct CrdCard{
    int  length;
    char startDg;
    
};

#ifdef __cplusplus
extern "C" {
#endif




#ifdef __cplusplus
}
#endif

#endif /* CRDCARD_H */

