/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Weather.h
 * Author: Jeff
 *
 * Created on March 22, 2017, 5:51 PM
 */

#ifndef WEATHER_H
#define WEATHER_H

struct Weather{
    float rain; //Total rainfall
    short higT; //Monthly high temp
    short lowT; //Monthly low temp
    float avgT; //Monthly average temp
};

#endif /* WEATHER_H */

