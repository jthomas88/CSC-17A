/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Drinks.h
 * Author: Jeff
 *
 * Created on March 24, 2017, 4:24 PM
 */

#ifndef DRINKS_H
#define DRINKS_H

struct Drink{
    std::string name; //Name of drink
    float  cost;      //Price of drink
    int    stok;      //Number of drinks available
};

#endif /* DRINKS_H */

