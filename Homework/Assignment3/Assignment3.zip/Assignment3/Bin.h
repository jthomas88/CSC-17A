/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Bin.h
 * Author: Jeff
 *
 * Created on March 24, 2017, 6:16 PM
 */

#ifndef BIN_H
#define BIN_H

struct Bin{
    std::string name; //Description of part
    int         stok; //Number of parts in bin
};

#endif /* BIN_H */

