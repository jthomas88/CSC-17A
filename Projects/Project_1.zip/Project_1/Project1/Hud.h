/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Hud.h
 * Author: Jeff
 *
 * Created on April 12, 2017, 9:56 AM
 */

#ifndef HUD_H
#define HUD_H

struct Hud{
    int   gold;
    int   food;
    float morale;
};

#endif /* HUD_H */

